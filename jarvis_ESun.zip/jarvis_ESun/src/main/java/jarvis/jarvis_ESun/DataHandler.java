package jarvis.jarvis_ESun;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.SQLException;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class DataHandler {
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";

    static final String USER = "root";
    static final String PASSWORD = "123456";
    
    static String DB_URL = null;
    static Connection conn = null;
    static Statement stmt = null;
    static CallableStatement callstmt = null;
         
    public DataHandler(String dbName, String table) {
    	try {
    		DB_URL = "jdbc:mysql://localhost:3306/" + dbName + "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
			conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
			stmt = conn.createStatement();			
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }
    
    public boolean sign_in(String phone_number, String password, String user_name) {    	
    	boolean result = false;
    	
    	try {
			Class.forName(JDBC_DRIVER);
		} 
		catch (ClassNotFoundException e) {
			throw new RuntimeException("time out");
		}
	
    	try { 
        	String sql = "{?= call sign_in(?,?,?) }";
        	callstmt = conn.prepareCall(sql);
        	callstmt.registerOutParameter(1, java.sql.Types.BOOLEAN);
        	callstmt.setString(2, phone_number);
        	callstmt.setString(3, hash(password));
        	callstmt.setString(4, user_name);
        	
        	result = callstmt.getBoolean(1);
        }
		catch(SQLException SQLe) {
			SQLe.printStackTrace();
		}
        catch(Exception e) {
        	e.printStackTrace();
        }
    	
    	return result;
    }
    
    public boolean login(String phone_number, String password) { 
    	boolean result = false;
    	
    	try {
			Class.forName(JDBC_DRIVER);
		} 
		catch (ClassNotFoundException e) {
			throw new RuntimeException("time out");
		}
	
    	try { 
        	String sql = "{?= call login(?,?) }";
        	callstmt = conn.prepareCall(sql);
        	callstmt.registerOutParameter(1, java.sql.Types.BOOLEAN);
        	callstmt.setString(2, phone_number);
        	callstmt.setString(3, hash(password));
        	
        	result = callstmt.getBoolean(1);
        }
		catch(SQLException SQLe) {
			SQLe.printStackTrace();
		}
        catch(Exception e) {
        	e.printStackTrace();
        }
    	
    	return result;
    }
    
    public boolean borrow_book(int user_id, int inventory_id) {
    	boolean result = false;
    	boolean auto_commit_default = false;
    	
    	try {
			Class.forName(JDBC_DRIVER);
		} 
		catch (ClassNotFoundException e) {
			throw new RuntimeException("time out");
		}
	
    	try { 
    		auto_commit_default = conn.getAutoCommit();
    		conn.setAutoCommit(false);
    		
        	String sql = "{?= call borrow_book(?,?) }";
        	callstmt = conn.prepareCall(sql);
        	callstmt.registerOutParameter(1, java.sql.Types.BOOLEAN);
        	callstmt.setInt(2, user_id);
        	callstmt.setInt(3, inventory_id);
        	
        	conn.commit(); 
        	
        	result = callstmt.getBoolean(1);
        }
		catch(SQLException SQLe) {
			SQLe.printStackTrace();
			
			try { 
		        conn.rollback();
		    } catch (Throwable ignore) {
		    	
		    }
		}
        catch(Exception e) {
        	e.printStackTrace();
        	try { 
		        conn.rollback();
		    } catch (Throwable ignore) {
		    	
		    }	
        }
    	finally {
            try { 
            	conn.setAutoCommit(auto_commit_default);
            } catch (Throwable ignore) {
            	
            }
        }
    	
    	return result;
    }
    
    public boolean return_book(int user_id, int inventory_id) { 
    	boolean result = false;
    	boolean auto_commit_default = false;
    	
    	try {
			Class.forName(JDBC_DRIVER);
		} 
		catch (ClassNotFoundException e) {
			throw new RuntimeException("time out");
		}
	
    	try { 
    		auto_commit_default = conn.getAutoCommit();
    		conn.setAutoCommit(false);
    		
        	String sql = "{?= call return_book(?,?) }";
        	callstmt = conn.prepareCall(sql);
        	callstmt.registerOutParameter(1, java.sql.Types.BOOLEAN);
        	callstmt.setInt(2, user_id);
        	callstmt.setInt(3, inventory_id);

        	conn.commit(); 
        	
        	result = callstmt.getBoolean(1);
        }
		catch(SQLException SQLe) {
			SQLe.printStackTrace();
			try { 
		        conn.rollback();
		    } catch (Throwable ignore) {
		    	
		    }
		}
        catch(Exception e) {
        	e.printStackTrace();
        	try { 
		        conn.rollback();
		    } catch (Throwable ignore) {
		    	
		    }
        }
    	finally {
            try { 
            	conn.setAutoCommit(auto_commit_default);
            } catch (Throwable ignore) {
            	
            }
        }
    	
    	return result;
    }
    
    private String hash(String password) {
    	SecureRandom random = new SecureRandom();
    	byte[] salt = new byte[16];
    	random.nextBytes(salt);
    	PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, 65536, 128);
    	SecretKeyFactory factory;
		try {
			factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			byte[] hash = factory.generateSecret(spec).getEncoded();
			return String.valueOf(hash);
		} catch (NoSuchAlgorithmException e) {
			// TODO 自動產生的 catch 區塊
			e.printStackTrace();
		} catch (InvalidKeySpecException e) {
			// TODO 自動產生的 catch 區塊
			e.printStackTrace();
		}
    	
		return null;
    }
  }

	